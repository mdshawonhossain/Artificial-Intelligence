/*Checking carnivore animals programme */
animal(cow).
animal(lion).
animal(tiger).
carnivore(lion).
carnivore(tiger).